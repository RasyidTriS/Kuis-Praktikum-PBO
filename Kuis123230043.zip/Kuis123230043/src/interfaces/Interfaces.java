package interfaces;

public interface Interfaces {
    void goBack();
}
