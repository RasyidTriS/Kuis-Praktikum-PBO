package abstracts;

//import javax.swing.*;
//import interfaces.Interfaces;
//import java.awt.*;

public abstract class Abstract {
    protected String nama;
    protected String nim;
    protected double writingScore;
    protected double codingScore;
    protected double interviewScore;
    
    public Abstract(String nama, String nim, double writingScore, double codingScore, double interviewScore) {
           this.nama = nama;
           this.nim = nim;
           this.writingScore = writingScore;
           this.codingScore = codingScore;
           this.interviewScore = interviewScore;
    }
    
    public abstract double hitungRataRata();
    
    public void cekHasil(String divisi) {
        if (hitungRataRata() >= 85) {
            System.out.println("DITERIMA! Selamat " + nama + " (" + nim + "), kamu diterima sebagai " + divisi);
        } else {
            System.out.println("TIDAK DITERIMA!, Maaf " + nama + " (" + nim + "), kamu tidak diterima sebagai " + divisi);
        }
    }
}
